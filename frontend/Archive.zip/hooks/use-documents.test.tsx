import { renderHook, act } from "@testing-library/react";
import { useDocuments } from "@/hooks/use-documents";
import { documentService } from "@/services/document-service";

// Mock document service
jest.mock("@/services/document-service", () => ({
  documentService: {
    getDocuments: jest.fn(),
    deleteDocument: jest.fn(),
  },
}));

describe("useDocuments Hook", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test("provides initial documents state", async () => {
    const mockDocuments = [
      { _id: "doc-1", title: "Document 1" },
      { _id: "doc-2", title: "Document 2" },
    ];

    const mockPagination = {
      page: 1,
      limit: 10,
      total: 2,
      pages: 1,
    };

    (documentService.getDocuments as jest.Mock).mockResolvedValue({
      documents: mockDocuments,
      pagination: mockPagination,
    });

    const { result } = renderHook(() => useDocuments());

    // Initial state should have loading true
    expect(result.current.isLoading).toBe(true);
    expect(result.current.documents).toEqual([]);

    // Wait for getDocuments to resolve
    await act(async () => {
      await new Promise((resolve) => setTimeout(resolve, 0));
    });

    // After loading, state should be updated
    expect(result.current.isLoading).toBe(false);
    expect(result.current.documents).toEqual(mockDocuments);
    expect(result.current.pagination).toEqual(mockPagination);
  });

  test("fetchDocuments updates documents state", async () => {
    const initialDocuments = [{ _id: "doc-1", title: "Document 1" }];

    const updatedDocuments = [
      { _id: "doc-2", title: "Document 2" },
      { _id: "doc-3", title: "Document 3" },
    ];

    (documentService.getDocuments as jest.Mock)
      .mockResolvedValueOnce({
        documents: initialDocuments,
        pagination: { page: 1, limit: 10, total: 1, pages: 1 },
      })
      .mockResolvedValueOnce({
        documents: updatedDocuments,
        pagination: { page: 1, limit: 10, total: 2, pages: 1 },
      });

    const { result } = renderHook(() => useDocuments());

    // Wait for initial getDocuments to resolve
    await act(async () => {
      await new Promise((resolve) => setTimeout(resolve, 0));
    });

    // Initial documents should be loaded
    expect(result.current.documents).toEqual(initialDocuments);

    // Call fetchDocuments with new params
    await act(async () => {
      await result.current.fetchDocuments({ search: "test" });
    });

    // Documents state should be updated
    expect(result.current.documents).toEqual(updatedDocuments);
    expect(documentService.getDocuments).toHaveBeenCalledWith({
      search: "test",
    });
  });

  test("deleteDocument removes document and refetches", async () => {
    const initialDocuments = [
      { _id: "doc-1", title: "Document 1" },
      { _id: "doc-2", title: "Document 2" },
    ];

    const updatedDocuments = [{ _id: "doc-2", title: "Document 2" }];

    (documentService.getDocuments as jest.Mock)
      .mockResolvedValueOnce({
        documents: initialDocuments,
        pagination: { page: 1, limit: 10, total: 2, pages: 1 },
      })
      .mockResolvedValueOnce({
        documents: updatedDocuments,
        pagination: { page: 1, limit: 10, total: 1, pages: 1 },
      });

    (documentService.deleteDocument as jest.Mock).mockResolvedValue({
      message: "Document deleted successfully",
    });

    const { result } = renderHook(() => useDocuments());

    // Wait for initial getDocuments to resolve
    await act(async () => {
      await new Promise((resolve) => setTimeout(resolve, 0));
    });

    // Initial documents should be loaded
    expect(result.current.documents).toEqual(initialDocuments);

    // Call deleteDocument
    await act(async () => {
      await result.current.deleteDocument("doc-1");
    });

    // Document service should be called
    expect(documentService.deleteDocument).toHaveBeenCalledWith("doc-1");

    // Documents should be refetched
    expect(result.current.documents).toEqual(updatedDocuments);
  });

  test("handles errors during document fetch", async () => {
    (documentService.getDocuments as jest.Mock).mockRejectedValue(
      new Error("Failed to fetch documents")
    );

    const { result } = renderHook(() => useDocuments());

    // Wait for getDocuments to reject
    await act(async () => {
      await new Promise((resolve) => setTimeout(resolve, 0));
    });

    // State should reflect error
    expect(result.current.isLoading).toBe(false);
    expect(result.current.error).toBe("Failed to fetch documents");
    expect(result.current.documents).toEqual([]);
  });

  test("handles errors during document deletion", async () => {
    const initialDocuments = [{ _id: "doc-1", title: "Document 1" }];

    (documentService.getDocuments as jest.Mock).mockResolvedValue({
      documents: initialDocuments,
      pagination: { page: 1, limit: 10, total: 1, pages: 1 },
    });

    (documentService.deleteDocument as jest.Mock).mockRejectedValue(
      new Error("Failed to delete document")
    );

    const { result } = renderHook(() => useDocuments());

    // Wait for initial getDocuments to resolve
    await act(async () => {
      await new Promise((resolve) => setTimeout(resolve, 0));
    });

    // Call deleteDocument and expect it to throw
    await expect(
      act(async () => {
        await result.current.deleteDocument("doc-1");
      })
    ).rejects.toThrow("Failed to delete document");

    // Documents state should remain unchanged
    expect(result.current.documents).toEqual(initialDocuments);
  });
});
