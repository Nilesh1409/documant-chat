import { rest } from "msw";

// Mock data
import { mockUsers } from "./data/users";
import { mockDocuments } from "./data/documents";
import { mockVersions } from "./data/versions";
import { mockQAHistory } from "./data/qa-history";

export const handlers = [
  // Auth endpoints
  rest.post("/api/auth/login", (req, res, ctx) => {
    const { email, password } = req.body;

    const user = mockUsers.find(
      (u) => u.email === email && password === "Password123!"
    );

    if (user) {
      return res(
        ctx.status(200),
        ctx.json({
          user,
          token: "mock-jwt-token",
        })
      );
    }

    return res(ctx.status(401), ctx.json({ message: "Invalid credentials" }));
  }),

  rest.post("/api/auth/register", (req, res, ctx) => {
    const { email } = req.body;

    if (mockUsers.some((u) => u.email === email)) {
      return res(ctx.status(400), ctx.json({ message: "User already exists" }));
    }

    return res(
      ctx.status(201),
      ctx.json({
        user: {
          _id: "new-user-id",
          ...req.body,
          role: "viewer",
          isActive: true,
          createdAt: new Date().toISOString(),
        },
        token: "mock-jwt-token",
      })
    );
  }),

  // User endpoints
  rest.get("/api/users", (req, res, ctx) => {
    const page = parseInt(req.url.searchParams.get("page") || "1");
    const limit = parseInt(req.url.searchParams.get("limit") || "10");
    const role = req.url.searchParams.get("role");

    let filteredUsers = [...mockUsers];

    if (role && role !== "all") {
      filteredUsers = filteredUsers.filter((user) => user.role === role);
    }

    const total = filteredUsers.length;
    const pages = Math.ceil(total / limit);
    const start = (page - 1) * limit;
    const end = start + limit;

    return res(
      ctx.status(200),
      ctx.json({
        users: filteredUsers.slice(start, end),
        pagination: {
          page,
          limit,
          total,
          pages,
        },
      })
    );
  }),

  rest.post("/api/users", (req, res, ctx) => {
    return res(
      ctx.status(201),
      ctx.json({
        user: {
          _id: "new-user-id",
          ...req.body,
          createdAt: new Date().toISOString(),
        },
      })
    );
  }),

  rest.put("/api/users/:id", (req, res, ctx) => {
    const { id } = req.params;
    const userIndex = mockUsers.findIndex((u) => u._id === id);

    if (userIndex === -1) {
      return res(ctx.status(404), ctx.json({ message: "User not found" }));
    }

    return res(
      ctx.status(200),
      ctx.json({
        user: {
          ...mockUsers[userIndex],
          ...req.body,
          _id: id,
        },
      })
    );
  }),

  rest.delete("/api/users/:id", (req, res, ctx) => {
    const { id } = req.params;
    const userIndex = mockUsers.findIndex((u) => u._id === id);

    if (userIndex === -1) {
      return res(ctx.status(404), ctx.json({ message: "User not found" }));
    }

    return res(
      ctx.status(200),
      ctx.json({ message: "User deleted successfully" })
    );
  }),

  // Document endpoints
  rest.get("/api/documents", (req, res, ctx) => {
    const page = parseInt(req.url.searchParams.get("page") || "1");
    const limit = parseInt(req.url.searchParams.get("limit") || "10");
    const search = req.url.searchParams.get("search") || "";
    const tags = req.url.searchParams.get("tags") || "";
    const userId = req.url.searchParams.get("userId");

    let filteredDocs = [...mockDocuments];

    if (search) {
      filteredDocs = filteredDocs.filter(
        (doc) =>
          doc.title.toLowerCase().includes(search.toLowerCase()) ||
          (doc.description &&
            doc.description.toLowerCase().includes(search.toLowerCase()))
      );
    }

    if (tags) {
      const tagArray = tags.split(",");
      filteredDocs = filteredDocs.filter((doc) =>
        tagArray.some((tag) => doc.tags.includes(tag))
      );
    }

    if (userId) {
      filteredDocs = filteredDocs.filter((doc) =>
        typeof doc.createdBy === "string"
          ? doc.createdBy === userId
          : doc.createdBy._id === userId
      );
    }

    const total = filteredDocs.length;
    const pages = Math.ceil(total / limit);
    const start = (page - 1) * limit;
    const end = start + limit;

    return res(
      ctx.status(200),
      ctx.json({
        documents: filteredDocs.slice(start, end),
        pagination: {
          page,
          limit,
          total,
          pages,
        },
      })
    );
  }),

  rest.get("/api/documents/:id", (req, res, ctx) => {
    const { id } = req.params;
    const document = mockDocuments.find((doc) => doc._id === id);

    if (!document) {
      return res(ctx.status(404), ctx.json({ message: "Document not found" }));
    }

    const latestVersion = mockVersions
      .filter((v) => v.documentId === id)
      .sort((a, b) => b.versionNumber - a.versionNumber)[0];

    return res(
      ctx.status(200),
      ctx.json({
        document,
        latestVersion,
      })
    );
  }),

  rest.get("/api/documents/:id/versions", (req, res, ctx) => {
    const { id } = req.params;
    const versions = mockVersions
      .filter((v) => v.documentId === id)
      .sort((a, b) => b.versionNumber - a.versionNumber);

    return res(ctx.status(200), ctx.json(versions));
  }),

  rest.get("/api/documents/:id/download", (req, res, ctx) => {
    return res(
      ctx.status(200),
      ctx.set("Content-Type", "application/pdf"),
      ctx.set("Content-Disposition", 'attachment; filename="document.pdf"'),
      ctx.body("mock pdf content")
    );
  }),

  rest.get(
    "/api/documents/:id/versions/:versionNumber/download",
    (req, res, ctx) => {
      const { versionNumber } = req.params;

      return res(
        ctx.status(200),
        ctx.set("Content-Type", "application/pdf"),
        ctx.set(
          "Content-Disposition",
          `attachment; filename="document-v${versionNumber}.pdf"`
        ),
        ctx.body("mock pdf content")
      );
    }
  ),

  rest.post("/api/documents", (req, res, ctx) => {
    return res(
      ctx.status(201),
      ctx.json({
        document: {
          _id: "new-document-id",
          ...req.body,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
      })
    );
  }),

  rest.put("/api/documents/:id", (req, res, ctx) => {
    const { id } = req.params;
    const docIndex = mockDocuments.findIndex((d) => d._id === id);

    if (docIndex === -1) {
      return res(ctx.status(404), ctx.json({ message: "Document not found" }));
    }

    return res(
      ctx.status(200),
      ctx.json({
        document: {
          ...mockDocuments[docIndex],
          ...req.body,
          _id: id,
          updatedAt: new Date().toISOString(),
        },
      })
    );
  }),

  rest.delete("/api/documents/:id", (req, res, ctx) => {
    const { id } = req.params;
    const docIndex = mockDocuments.findIndex((d) => d._id === id);

    if (docIndex === -1) {
      return res(ctx.status(404), ctx.json({ message: "Document not found" }));
    }

    return res(
      ctx.status(200),
      ctx.json({ message: "Document deleted successfully" })
    );
  }),

  // QA endpoints
  rest.post("/api/qa/ask", (req, res, ctx) => {
    const { question } = req.body;

    return res(
      ctx.status(200),
      ctx.json({
        answer: `This is a mock answer to the question: "${question}"`,
        sources: [
          {
            documentId: mockDocuments[0]._id,
            title: mockDocuments[0].title,
            excerpts: ["Relevant excerpt from the document"],
            metadata: { author: "John Doe" },
          },
        ],
        confidence: "high",
      })
    );
  }),

  rest.get("/api/qa/history", (req, res, ctx) => {
    const page = parseInt(req.url.searchParams.get("page") || "1");
    const limit = parseInt(req.url.searchParams.get("limit") || "10");

    const total = mockQAHistory.length;
    const pages = Math.ceil(total / limit);
    const start = (page - 1) * limit;
    const end = start + limit;

    return res(
      ctx.status(200),
      ctx.json({
        history: mockQAHistory.slice(start, end),
        pagination: {
          page,
          limit,
          total,
          pages,
        },
      })
    );
  }),

  rest.delete("/api/qa/history/:id", (req, res, ctx) => {
    return res(
      ctx.status(200),
      ctx.json({ message: "History item deleted successfully" })
    );
  }),

  rest.delete("/api/qa/history", (req, res, ctx) => {
    return res(
      ctx.status(200),
      ctx.json({ message: "History cleared successfully" })
    );
  }),

  // Ingestion endpoints
  rest.post("/api/documents/:id/index", (req, res, ctx) => {
    return res(
      ctx.status(200),
      ctx.json({ message: "Document indexing started" })
    );
  }),

  rest.get("/api/ingestion", (req, res, ctx) => {
    return res(
      ctx.status(200),
      ctx.json({
        jobs: [
          {
            _id: "job-1",
            documentId: mockDocuments[0],
            status: "completed",
            startedAt: new Date().toISOString(),
            completedAt: new Date().toISOString(),
          },
          {
            _id: "job-2",
            documentId: mockDocuments[1],
            status: "processing",
            startedAt: new Date().toISOString(),
            completedAt: null,
          },
        ],
        pagination: {
          page: 1,
          limit: 10,
          total: 2,
          pages: 1,
        },
      })
    );
  }),
];
