import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import DocumentUploadButton from "@/components/documents/document-upload-button";
import { AuthProvider } from "@/providers/auth-provider";
import { documentService } from "@/services/document-service";

// Mock document service
jest.mock("@/services/document-service", () => ({
  documentService: {
    uploadDocument: jest.fn(),
  },
}));

describe("DocumentUploadButton Component", () => {
  const mockOnSuccess = jest.fn();

  const renderUploadButton = () => {
    return render(
      <AuthProvider initialUser={{ _id: "user-1" }} initialLoading={false}>
        <DocumentUploadButton onSuccess={mockOnSuccess} />
      </AuthProvider>
    );
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  test("renders upload button correctly", () => {
    renderUploadButton();

    const uploadButton = screen.getByRole("button", {
      name: /upload document/i,
    });
    expect(uploadButton).toBeInTheDocument();
  });

  test("opens dialog when button is clicked", () => {
    renderUploadButton();

    // Dialog should not be visible initially
    expect(screen.queryByText("Upload Document")).not.toBeInTheDocument();

    // Click upload button
    const uploadButton = screen.getByRole("button", {
      name: /upload document/i,
    });
    fireEvent.click(uploadButton);

    // Dialog should now be visible
    expect(screen.getByText("Upload Document")).toBeInTheDocument();
    expect(
      screen.getByText("Upload a new document to your library")
    ).toBeInTheDocument();
  });

  test("handles file selection", async () => {
    renderUploadButton();

    // Open dialog
    const uploadButton = screen.getByRole("button", {
      name: /upload document/i,
    });
    fireEvent.click(uploadButton);

    // Create a mock file
    const file = new File(["dummy content"], "test.pdf", {
      type: "application/pdf",
    });

    // Get file input and simulate file selection
    const fileInput = screen.getByLabelText(/drop your file here/i);
    fireEvent.change(fileInput, { target: { files: [file] } });

    // File name should be displayed
    await waitFor(() => {
      expect(screen.getByText("test.pdf")).toBeInTheDocument();
    });
  });

  test("submits form with file and metadata", async () => {
    // Mock successful upload
    (documentService.uploadDocument as jest.Mock).mockResolvedValue({
      document: { _id: "new-doc-id", title: "Test Document" },
    });

    renderUploadButton();

    // Open dialog
    const uploadButton = screen.getByRole("button", {
      name: /upload document/i,
    });
    fireEvent.click(uploadButton);

    // Create a mock file
    const file = new File(["dummy content"], "test.pdf", {
      type: "application/pdf",
    });

    // Get file input and simulate file selection
    const fileInput = screen.getByLabelText(/drop your file here/i);
    fireEvent.change(fileInput, { target: { files: [file] } });

    // Fill in form fields
    const titleInput = screen.getByLabelText(/title/i);
    fireEvent.change(titleInput, { target: { value: "Test Document" } });

    const descriptionInput = screen.getByLabelText(/description/i);
    fireEvent.change(descriptionInput, {
      target: { value: "This is a test document" },
    });

    const tagsInput = screen.getByLabelText(/tags/i);
    fireEvent.change(tagsInput, { target: { value: "test, document" } });

    // Submit form
    const submitButton = screen.getByRole("button", { name: /upload/i });
    fireEvent.click(submitButton);

    // Check if service was called with correct data
    await waitFor(() => {
      expect(documentService.uploadDocument).toHaveBeenCalledWith(
        expect.any(FormData),
        "user-1"
      );

      // Check if onSuccess callback was called
      expect(mockOnSuccess).toHaveBeenCalled();
    });
  });

  test("displays error when upload fails", async () => {
    // Mock failed upload
    (documentService.uploadDocument as jest.Mock).mockRejectedValue(
      new Error("Upload failed")
    );

    renderUploadButton();

    // Open dialog
    const uploadButton = screen.getByRole("button", {
      name: /upload document/i,
    });
    fireEvent.click(uploadButton);

    // Create a mock file
    const file = new File(["dummy content"], "test.pdf", {
      type: "application/pdf",
    });

    // Get file input and simulate file selection
    const fileInput = screen.getByLabelText(/drop your file here/i);
    fireEvent.change(fileInput, { target: { files: [file] } });

    // Fill in form fields
    const titleInput = screen.getByLabelText(/title/i);
    fireEvent.change(titleInput, { target: { value: "Test Document" } });

    // Submit form
    const submitButton = screen.getByRole("button", { name: /upload/i });
    fireEvent.click(submitButton);

    // Error should be displayed
    await waitFor(() => {
      expect(screen.getByText("Upload failed")).toBeInTheDocument();
    });
  });
});
