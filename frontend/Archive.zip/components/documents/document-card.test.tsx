import { render, screen, fireEvent } from "@testing-library/react";
import DocumentCard from "@/components/documents/document-card";
import { AuthProvider } from "@/providers/auth-provider";

// Mock router
jest.mock("next/navigation", () => ({
  ...jest.requireActual("next/navigation"),
  useRouter: () => ({
    push: jest.fn(),
  }),
}));

describe("DocumentCard Component", () => {
  const mockDocument = {
    _id: "doc-1",
    title: "Test Document",
    description: "This is a test document",
    fileType: "application/pdf",
    fileSize: 1024 * 1024, // 1MB
    tags: ["test", "document"],
    createdBy: {
      _id: "user-1",
      email: "test@example.com",
      fullName: "Test User",
    },
    createdAt: "2023-01-01T00:00:00.000Z",
    updatedAt: "2023-01-02T00:00:00.000Z",
  };

  const mockOnDelete = jest.fn();

  const renderDocumentCard = (isOwner = false) => {
    const mockUser = {
      _id: isOwner ? "user-1" : "user-2",
      email: "test@example.com",
      firstName: "Test",
      lastName: "User",
      role: "viewer",
    };

    return render(
      <AuthProvider initialUser={mockUser} initialLoading={false}>
        <DocumentCard document={mockDocument} onDelete={mockOnDelete} />
      </AuthProvider>
    );
  };

  test("renders document information correctly", () => {
    renderDocumentCard();

    expect(screen.getByText("Test Document")).toBeInTheDocument();
    expect(screen.getByText("This is a test document")).toBeInTheDocument();
    expect(screen.getByText("PDF")).toBeInTheDocument();
    expect(screen.getByText("1.00 MB")).toBeInTheDocument();

    // Check for tags
    expect(screen.getByText("test")).toBeInTheDocument();
    expect(screen.getByText("document")).toBeInTheDocument();
  });

  test("shows view button for all users", () => {
    renderDocumentCard();

    const viewButton = screen.getByRole("link", { name: /view/i });
    expect(viewButton).toBeInTheDocument();
    expect(viewButton.getAttribute("href")).toBe("/documents/doc-1");
  });

  test("shows edit and delete buttons for document owner", () => {
    renderDocumentCard(true);

    // Edit button should be visible and link to edit page
    const editButton = screen.getByRole("link", { name: /edit/i });
    expect(editButton).toBeInTheDocument();
    expect(editButton.getAttribute("href")).toBe("/documents/doc-1/edit");

    // Delete button should be visible
    const deleteButton = screen.getByRole("button", { name: /delete/i });
    expect(deleteButton).toBeInTheDocument();
  });

  test("does not show edit and delete buttons for non-owners", () => {
    renderDocumentCard(false);

    // Edit and delete buttons should not be visible
    expect(
      screen.queryByRole("link", { name: /edit/i })
    ).not.toBeInTheDocument();
    expect(
      screen.queryByRole("button", { name: /delete/i })
    ).not.toBeInTheDocument();
  });

  test("calls onDelete when delete button is clicked and confirmed", () => {
    // Mock window.confirm to return true
    window.confirm = jest.fn().mockImplementation(() => true);

    renderDocumentCard(true);

    // Click delete button
    const deleteButton = screen.getByRole("button", { name: /delete/i });
    fireEvent.click(deleteButton);

    // Confirm dialog should be shown
    expect(window.confirm).toHaveBeenCalled();

    // onDelete should be called with document ID
    expect(mockOnDelete).toHaveBeenCalled();
  });

  test("does not call onDelete when delete is canceled", () => {
    // Mock window.confirm to return false
    window.confirm = jest.fn().mockImplementation(() => false);

    renderDocumentCard(true);

    // Click delete button
    const deleteButton = screen.getByRole("button", { name: /delete/i });
    fireEvent.click(deleteButton);

    // Confirm dialog should be shown
    expect(window.confirm).toHaveBeenCalled();

    // onDelete should not be called
    expect(mockOnDelete).not.toHaveBeenCalled();
  });
});
