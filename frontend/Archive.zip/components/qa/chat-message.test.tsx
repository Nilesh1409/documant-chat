import { render, screen, fireEvent } from "@testing-library/react";
import { ChatMessage } from "@/components/qa/chat-message";

describe("ChatMessage Component", () => {
  test("renders user message correctly", () => {
    render(<ChatMessage type="user" content="What is the revenue for 2023?" />);

    expect(screen.getByText("You")).toBeInTheDocument();
    expect(
      screen.getByText("What is the revenue for 2023?")
    ).toBeInTheDocument();
  });

  test("renders assistant message correctly", () => {
    const content = {
      answer: "The revenue for 2023 was $10.5 million.",
      sources: [
        {
          documentId: "doc-1",
          title: "Annual Report 2023",
          excerpts: [
            "The company reported total revenues of $10.5 million for the fiscal year 2023.",
          ],
          metadata: { author: "Finance Team" },
        },
      ],
      confidence: "high",
    };

    render(<ChatMessage type="assistant" content={content} />);

    expect(screen.getByText("Assistant")).toBeInTheDocument();
    expect(
      screen.getByText("The revenue for 2023 was $10.5 million.")
    ).toBeInTheDocument();
    expect(screen.getByText("High confidence")).toBeInTheDocument();
    expect(screen.getByText("Sources (1)")).toBeInTheDocument();
  });

  test("sources are initially collapsed", () => {
    const content = {
      answer: "The revenue for 2023 was $10.5 million.",
      sources: [
        {
          documentId: "doc-1",
          title: "Annual Report 2023",
          excerpts: [
            "The company reported total revenues of $10.5 million for the fiscal year 2023.",
          ],
          metadata: { author: "Finance Team" },
        },
      ],
      confidence: "high",
    };

    render(<ChatMessage type="assistant" content={content} />);

    // Sources button should be visible
    expect(screen.getByText("Sources (1)")).toBeInTheDocument();

    // Source details should not be visible initially
    expect(screen.queryByText("Annual Report 2023")).not.toBeInTheDocument();
  });

  test("clicking sources button expands source details", () => {
    const content = {
      answer: "The revenue for 2023 was $10.5 million.",
      sources: [
        {
          documentId: "doc-1",
          title: "Annual Report 2023",
          excerpts: [
            "The company reported total revenues of $10.5 million for the fiscal year 2023.",
          ],
          metadata: { author: "Finance Team" },
        },
      ],
      confidence: "high",
    };

    render(<ChatMessage type="assistant" content={content} />);

    // Click sources button
    const sourcesButton = screen.getByText("Sources (1)");
    fireEvent.click(sourcesButton);

    // Source details should now be visible
    expect(screen.getByText("Annual Report 2023")).toBeInTheDocument();
    expect(screen.getByText("By Finance Team")).toBeInTheDocument();
  });

  test("source excerpts are initially collapsed", () => {
    const content = {
      answer: "The revenue for 2023 was $10.5 million.",
      sources: [
        {
          documentId: "doc-1",
          title: "Annual Report 2023",
          excerpts: [
            "The company reported total revenues of $10.5 million for the fiscal year 2023.",
          ],
          metadata: { author: "Finance Team" },
        },
      ],
      confidence: "high",
    };

    render(<ChatMessage type="assistant" content={content} />);

    // Click sources button to expand sources
    const sourcesButton = screen.getByText("Sources (1)");
    fireEvent.click(sourcesButton);

    // Source title should be visible
    expect(screen.getByText("Annual Report 2023")).toBeInTheDocument();

    // Excerpt should not be visible initially
    expect(
      screen.queryByText(
        "The company reported total revenues of $10.5 million for the fiscal year 2023."
      )
    ).not.toBeInTheDocument();
  });

  test("clicking expand button shows source excerpts", () => {
    const content = {
      answer: "The revenue for 2023 was $10.5 million.",
      sources: [
        {
          documentId: "doc-1",
          title: "Annual Report 2023",
          excerpts: [
            "The company reported total revenues of $10.5 million for the fiscal year 2023.",
          ],
          metadata: { author: "Finance Team" },
        },
      ],
      confidence: "high",
    };

    render(<ChatMessage type="assistant" content={content} />);

    // Click sources button to expand sources
    const sourcesButton = screen.getByText("Sources (1)");
    fireEvent.click(sourcesButton);

    // Click expand button for the source
    const expandButton = screen.getByRole("button", { name: "" });
    fireEvent.click(expandButton);

    // Excerpt should now be visible
    expect(
      screen.getByText(
        "The company reported total revenues of $10.5 million for the fiscal year 2023."
      )
    ).toBeInTheDocument();
  });

  test("handles assistant message without sources", () => {
    const content = {
      answer: "I don't have information about that.",
      sources: [],
      confidence: "low",
    };

    render(<ChatMessage type="assistant" content={content} />);

    expect(screen.getByText("Assistant")).toBeInTheDocument();
    expect(
      screen.getByText("I don't have information about that.")
    ).toBeInTheDocument();
    expect(screen.getByText("Low confidence")).toBeInTheDocument();

    // Sources section should not be present
    expect(screen.queryByText("Sources")).not.toBeInTheDocument();
  });
});
