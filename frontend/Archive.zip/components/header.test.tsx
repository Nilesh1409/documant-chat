import { render, screen, fireEvent } from "@testing-library/react";
import Header from "@/components/header";
import { AuthProvider } from "@/providers/auth-provider";

// Mock the useRouter hook
jest.mock("next/navigation", () => ({
  ...jest.requireActual("next/navigation"),
  useRouter: () => ({
    push: jest.fn(),
  }),
  usePathname: () => "/",
}));

describe("Header Component", () => {
  const renderHeader = (isAuthenticated = false, userRole = "viewer") => {
    const mockUser = isAuthenticated
      ? {
          _id: "user-1",
          email: "test@example.com",
          firstName: "Test",
          lastName: "User",
          role: userRole,
        }
      : null;

    return render(
      <AuthProvider initialUser={mockUser} initialLoading={false}>
        <Header />
      </AuthProvider>
    );
  };

  test("renders logo and navigation links", () => {
    renderHeader();

    // Check for logo
    expect(screen.getByText("DocManager")).toBeInTheDocument();

    // Check for navigation links
    expect(screen.getByText("Home")).toBeInTheDocument();
    expect(screen.getByText("Documents")).toBeInTheDocument();
    expect(screen.getByText("About")).toBeInTheDocument();
  });

  test("shows login and signup buttons when user is not authenticated", () => {
    renderHeader(false);

    expect(screen.getByText("Log in")).toBeInTheDocument();
    expect(screen.getByText("Sign up")).toBeInTheDocument();
  });

  test("shows user dropdown when user is authenticated", () => {
    renderHeader(true);

    // User dropdown should be visible
    const userButton = screen.getByRole("button", { name: /test/i });
    expect(userButton).toBeInTheDocument();

    // Click to open dropdown
    fireEvent.click(userButton);

    // Check dropdown content
    expect(screen.getByText("Profile")).toBeInTheDocument();
    expect(screen.getByText("My Documents")).toBeInTheDocument();
    expect(screen.getByText("Log out")).toBeInTheDocument();
  });

  test("shows admin panel link for admin users", () => {
    renderHeader(true, "admin");

    // Admin button should be visible
    expect(screen.getByText("Admin")).toBeInTheDocument();

    // Open user dropdown
    const userButton = screen.getByRole("button", { name: /test/i });
    fireEvent.click(userButton);

    // Admin Panel link should be in dropdown
    expect(screen.getByText("Admin Panel")).toBeInTheDocument();
  });

  test("does not show admin panel link for non-admin users", () => {
    renderHeader(true, "viewer");

    // Admin button should not be visible
    expect(screen.queryByText("Admin")).not.toBeInTheDocument();

    // Open user dropdown
    const userButton = screen.getByRole("button", { name: /test/i });
    fireEvent.click(userButton);

    // Admin Panel link should not be in dropdown
    expect(screen.queryByText("Admin Panel")).not.toBeInTheDocument();
  });

  test("mobile menu toggle works correctly", () => {
    // Mock window width to simulate mobile view
    global.innerWidth = 500;
    global.dispatchEvent(new Event("resize"));

    renderHeader();

    // Mobile menu button should be visible
    const menuButton = screen.getByRole("button", { name: "" });
    expect(menuButton).toBeInTheDocument();

    // Menu should be hidden initially
    expect(screen.queryByText("Log in")).not.toBeVisible();

    // Click to open menu
    fireEvent.click(menuButton);

    // Menu should now be visible
    expect(screen.getByText("Log in")).toBeVisible();

    // Click again to close
    fireEvent.click(menuButton);

    // Menu should be hidden again
    expect(screen.queryByText("Log in")).not.toBeVisible();
  });
});
