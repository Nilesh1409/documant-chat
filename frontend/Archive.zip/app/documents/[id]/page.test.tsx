import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import DocumentPage from '@/app/documents/[id]/page';
import { AuthProvider } from '@/providers/auth-provider';
import { documentService } from '@/services/document-service';
import { qaService } from '@/services/qa-service';

// Mock document and qa services
jest.mock('@/services/document-service', () => ({
  documentService: {
    getDocumentById: jest.fn(),
    getDocumentVersions: jest.fn(),
    deleteDocument: jest.fn(),
    downloadDocument: jest.fn(),
    downloadDocumentVersion: jest.fn(),
  },
}));

jest.mock('@/services/qa-service', () => ({
  qaService: {
    indexDocument: jest.fn(),
  },
}));

// Mock next/navigation
jest.mock('next/navigation', () => ({
  ...jest.requireActual('next/navigation'),
  useRouter: () => ({
    push: jest.fn(),
  }),
}));

describe('Document Detail Page', () => {
  const mockDocument = {
    _id: 'doc-1',
    title: 'Annual Report 2023',
    description: 'Annual financial report',
    fileType: 'application/pdf',
    fileSize: 1024 * 1024,
    fileUrl: '/uploads/annual-report.pdf',
    tags: ['report', 'financial'],
    createdBy: { _id: 'user-1', email: 'test@example.com', fullName: 'Test User' },
    createdAt: '2023-01-01T00:00:00.000Z',
    updatedAt: '2023-01-01T00:00:00.000Z',
  };

  const mockVersions = [
    {
      _id: 'version-1',
      documentId: 'doc-1',
      versionNumber: 1,
      fileUrl: '/uploads/annual-report-v1.pdf',
      changeSummary: 'Initial version',
      createdBy: { _id: 'user-1', email: 'test@example.com', fullName: 'Test User' },
      createdAt: '2023-01-01T00:00:00.000Z',
    },
    {
      _id: 'version-2',
      documentId: 'doc-1',
      versionNumber: 2,
      fileUrl: '/uploads/annual-report-v2.pdf',
      changeSummary: 'Updated financial figures',
      createdBy: { _id: 'user-1', email: 'test@example.com', fullName: 'Test User' },
      createdAt: '2023-01-15T00:00:00.000Z',
    },
  ];

  beforeEach(() => {
    jest.clearAllMocks();
    
    // Mock successful document fetch
    (documentService.getDocumentById as jest.Mock).mockResolvedValue({
      document: mockDocument,
      latestVersion: mockVersions[1],
    });
    
    // Mock successful versions fetch
    (documentService.getDocumentVersions as jest.Mock).mockResolvedValue(mockVersions);
    
    // Mock successful download
    (documentService.downloadDocument as jest.Mock).mockResolvedValue(new Blob(['mock pdf content'], { type: 'application/pdf' }));
    (documentService.downloadDocumentVersion as jest.Mock).mockResolvedValue(new Blob(['mock pdf content'], { type: 'application/pdf' }));
  });

  const renderDocumentPage = (isOwner = true) => {
    const mockUser = {
      _id: isOwner ? 'user-1' : 'user-2',
      email: 'test@example.com',
      role: 'viewer',
    };
    
    return render(
      <AuthProvider initialUser={mockUser} initialLoading={false}>
        <DocumentPage params={{ id: 'doc-1' }} />
      </AuthProvider>
    );
  };

  test('renders document title and metadata', async () => {
    renderDocumentPage();
    
    await waitFor(() => {
      expect(screen.getByText('Annual Report 2023')).toBeInTheDocument();
      expect(screen.getByText('Annual financial report')).toBeInTheDocument();
      expect(screen.getByText('PDF')).toBeInTheDocument();
      expect(screen.getByText('1.00 MB')).toBeInTheDocument();
    });
  });

  test('renders document preview tab', async () => {
    renderDocumentPage();
    
    await waitFor(() => {
      expect(screen.getByRole('tab', { name: /preview/i })).toBeInTheDocument();
      expect(screen.getByText('Download to view')).toBeInTheDocument();
    });
  });

  test('renders versions tab with version history', async () => {
    renderDocumentPage();
    
    await waitFor(() => {
      const versionsTab = screen.getByRole('tab', { name: /versions/i });
      expect(versionsTab).toBeInTheDocument();
      expect(versionsTab.textContent).toContain('2'); // Number of versions
      
      // Click on versions tab
      fireEvent.click(versionsTab);
      
      // Version history should be visible
      expect(screen.getByText('Version 1')).toBeInTheDocument();
      expect(screen.getByText('Version 2')).toBeInTheDocument();
      expect(screen.getByText('Initial version')).toBeInTheDocument();
      expect(screen.getByText('Updated financial figures')).toBeInTheDocument();
      expect(screen.getByText('Latest')).toBeInTheDocument();
    });
  });

  test('shows document details sidebar', async () => {
    renderDocumentPage();
    
    await waitFor(() => {
      expect(screen.getByText('Details')).toBeInTheDocument();
      expect(screen.getByText('Owner')).toBeInTheDocument();
      expect(screen.getByText('Test User')).toBeInTheDocument();
      expect(screen.getByText('Created')).toBeInTheDocument();
      expect(screen.getByText('File Type')).toBeInTheDocument();
      expect(screen.getByText('File Size')).toBeInTheDocument();
    });
  });

  test('shows tags in sidebar', async () => {
    renderDocumentPage();
    
    await waitFor(() => {
      expect(screen.getByText('Tags')).toBeInTheDocument();
      expect(screen.getByText('report')).toBeInTheDocument();
      expect(screen.getByText('financial')).toBeInTheDocument();
    });
  });

  test('shows actions sidebar for document owner', async () => {
    renderDocumentPage(true);
    
    await waitFor(() => {
      expect(screen.getByText('Actions')).toBeInTheDocument();
      expect(screen.getByText('Manage permissions')).toBeInTheDocument();
      expect(screen.getByText('Edit document')).toBeInTheDocument();
      expect(screen.getByText('Delete document')).toBeInTheDocument();
      expect(screen.getByText('Index for Q&A')).toBeInTheDocument();
    });
  });