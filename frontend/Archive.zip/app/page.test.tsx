import { render, screen } from "@testing-library/react";
import HomePage from "@/app/page";

// Mock next/link
jest.mock("next/link", () => {
  return ({ children, href }: { children: React.ReactNode; href: string }) => {
    return <a href={href}>{children}</a>;
  };
});

describe("Home Page", () => {
  test("renders hero section with title and description", () => {
    render(<HomePage />);

    expect(
      screen.getByText("Manage Your Documents with Ease and Security")
    ).toBeInTheDocument();
    expect(
      screen.getByText(
        /A powerful document management system that helps you organize, share, and collaborate/i
      )
    ).toBeInTheDocument();
  });

  test("renders call-to-action buttons", () => {
    render(<HomePage />);

    const browseButton = screen.getByRole("link", {
      name: /browse documents/i,
    });
    expect(browseButton).toBeInTheDocument();
    expect(browseButton.getAttribute("href")).toBe("/documents");

    const getStartedButton = screen.getByRole("link", { name: /get started/i });
    expect(getStartedButton).toBeInTheDocument();
    expect(getStartedButton.getAttribute("href")).toBe("/auth/register");
  });

  test("renders features section with all features", () => {
    render(<HomePage />);

    expect(screen.getByText("Powerful Features")).toBeInTheDocument();

    // Check for all feature cards
    expect(screen.getByText("Document Management")).toBeInTheDocument();
    expect(screen.getByText("User Permissions")).toBeInTheDocument();
    expect(screen.getByText("Version Control")).toBeInTheDocument();
  });

  test("renders CTA section at the bottom", () => {
    render(<HomePage />);

    expect(screen.getByText("Ready to get started?")).toBeInTheDocument();

    const createAccountButton = screen.getByRole("link", {
      name: /create your account/i,
    });
    expect(createAccountButton).toBeInTheDocument();
    expect(createAccountButton.getAttribute("href")).toBe("/auth/register");
  });
});
