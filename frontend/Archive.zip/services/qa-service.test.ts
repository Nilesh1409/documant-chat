import { qaService } from "@/services/qa-service";
import { api } from "@/lib/api";

// Mock axios
jest.mock("@/lib/api", () => ({
  api: {
    post: jest.fn(),
    get: jest.fn(),
    delete: jest.fn(),
  },
}));

describe("QA Service", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe("askQuestion", () => {
    test("sends question and returns answer with sources", async () => {
      const mockResponse = {
        data: {
          answer: "This is the answer to your question.",
          sources: [
            {
              documentId: "doc-1",
              title: "Document 1",
              excerpts: ["Relevant excerpt from the document"],
            },
          ],
          confidence: "high",
        },
      };

      (api.post as jest.Mock).mockResolvedValue(mockResponse);

      const result = await qaService.askQuestion(
        "What is the revenue for 2023?"
      );

      expect(api.post).toHaveBeenCalledWith("/qa/ask", {
        question: "What is the revenue for 2023?",
      });

      expect(result).toEqual(mockResponse.data);
    });
  });

  describe("getQAHistory", () => {
    test("fetches QA history with default parameters", async () => {
      const mockResponse = {
        data: {
          history: [
            {
              _id: "qa-1",
              question: "What is the revenue?",
              answer: "The revenue is $10M",
            },
          ],
          pagination: {
            page: 1,
            limit: 10,
            total: 1,
            pages: 1,
          },
        },
      };

      (api.get as jest.Mock).mockResolvedValue(mockResponse);

      const result = await qaService.getQAHistory();

      expect(api.get).toHaveBeenCalledWith("/qa/history", {
        params: { page: 1, limit: 10 },
      });

      expect(result).toEqual(mockResponse.data);
    });

    test("fetches QA history with custom parameters", async () => {
      const mockResponse = {
        data: {
          history: [
            {
              _id: "qa-1",
              question: "What is the revenue?",
              answer: "The revenue is $10M",
            },
          ],
          pagination: {
            page: 2,
            limit: 5,
            total: 6,
            pages: 2,
          },
        },
      };

      (api.get as jest.Mock).mockResolvedValue(mockResponse);

      const result = await qaService.getQAHistory({ page: 2, limit: 5 });

      expect(api.get).toHaveBeenCalledWith("/qa/history", {
        params: { page: 2, limit: 5 },
      });

      expect(result).toEqual(mockResponse.data);
    });
  });

  describe("deleteQAHistoryItem", () => {
    test("deletes specific QA history item", async () => {
      const mockResponse = {
        data: { message: "History item deleted successfully" },
      };

      (api.delete as jest.Mock).mockResolvedValue(mockResponse);

      const result = await qaService.deleteQAHistoryItem("qa-1");

      expect(api.delete).toHaveBeenCalledWith("/qa/history/qa-1");
      expect(result).toEqual(mockResponse.data);
    });
  });

  describe("clearQAHistory", () => {
    test("clears all QA history", async () => {
      const mockResponse = {
        data: { message: "History cleared successfully" },
      };

      (api.delete as jest.Mock).mockResolvedValue(mockResponse);

      const result = await qaService.clearQAHistory();

      expect(api.delete).toHaveBeenCalledWith("/qa/history");
      expect(result).toEqual(mockResponse.data);
    });
  });

  describe("indexDocument", () => {
    test("starts document indexing process", async () => {
      const mockResponse = {
        data: { message: "Document indexing started" },
      };

      (api.post as jest.Mock).mockResolvedValue(mockResponse);

      const result = await qaService.indexDocument("doc-1");

      expect(api.post).toHaveBeenCalledWith("/documents/doc-1/index");
      expect(result).toEqual(mockResponse.data);
    });
  });
});
