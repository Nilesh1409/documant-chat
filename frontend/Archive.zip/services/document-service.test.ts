import { documentService } from "@/services/document-service";
import { api } from "@/lib/api";

// Mock axios
jest.mock("@/lib/api", () => ({
  api: {
    get: jest.fn(),
    post: jest.fn(),
    put: jest.fn(),
    delete: jest.fn(),
  },
}));

describe("Document Service", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe("getDocuments", () => {
    test("fetches documents with default parameters", async () => {
      const mockResponse = {
        data: {
          documents: [
            { _id: "doc-1", title: "Document 1" },
            { _id: "doc-2", title: "Document 2" },
          ],
          pagination: {
            page: 1,
            limit: 10,
            total: 2,
            pages: 1,
          },
        },
      };

      (api.get as jest.Mock).mockResolvedValue(mockResponse);

      const result = await documentService.getDocuments();

      expect(api.get).toHaveBeenCalledWith("/documents", {
        params: { page: 1, limit: 10 },
      });

      expect(result).toEqual(mockResponse.data);
    });

    test("fetches documents with custom parameters", async () => {
      const mockResponse = {
        data: {
          documents: [{ _id: "doc-1", title: "Document 1" }],
          pagination: {
            page: 2,
            limit: 5,
            total: 6,
            pages: 2,
          },
        },
      };

      (api.get as jest.Mock).mockResolvedValue(mockResponse);

      const result = await documentService.getDocuments({
        page: 2,
        limit: 5,
        search: "report",
        tags: ["financial"],
        userId: "user-1",
      });

      expect(api.get).toHaveBeenCalledWith("/documents", {
        params: {
          page: 2,
          limit: 5,
          search: "report",
          tags: "financial",
          userId: "user-1",
        },
      });

      expect(result).toEqual(mockResponse.data);
    });
  });

  describe("getDocumentById", () => {
    test("fetches document by ID", async () => {
      const mockResponse = {
        data: {
          document: { _id: "doc-1", title: "Document 1" },
          latestVersion: { _id: "version-1", versionNumber: 1 },
        },
      };

      (api.get as jest.Mock).mockResolvedValue(mockResponse);

      const result = await documentService.getDocumentById("doc-1");

      expect(api.get).toHaveBeenCalledWith("/documents/doc-1");
      expect(result).toEqual(mockResponse.data);
    });
  });

  describe("getDocumentVersions", () => {
    test("fetches document versions", async () => {
      const mockResponse = {
        data: [
          { _id: "version-1", versionNumber: 1 },
          { _id: "version-2", versionNumber: 2 },
        ],
      };

      (api.get as jest.Mock).mockResolvedValue(mockResponse);

      const result = await documentService.getDocumentVersions("doc-1");

      expect(api.get).toHaveBeenCalledWith("/documents/doc-1/versions");
      expect(result).toEqual(mockResponse.data);
    });
  });

  describe("uploadDocument", () => {
    test("uploads document with form data", async () => {
      const mockResponse = {
        data: {
          document: { _id: "new-doc", title: "New Document" },
        },
      };

      (api.post as jest.Mock).mockResolvedValue(mockResponse);

      const formData = new FormData();
      formData.append(
        "file",
        new File(["test"], "test.pdf", { type: "application/pdf" })
      );
      formData.append("title", "New Document");

      const result = await documentService.uploadDocument(formData, "user-1");

      expect(api.post).toHaveBeenCalledWith("/documents", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      expect(result).toEqual(mockResponse.data);
    });
  });

  describe("updateDocument", () => {
    test("updates document metadata", async () => {
      const mockResponse = {
        data: {
          document: { _id: "doc-1", title: "Updated Document" },
        },
      };

      (api.put as jest.Mock).mockResolvedValue(mockResponse);

      const updateData = {
        title: "Updated Document",
        description: "Updated description",
        tags: ["updated", "document"],
      };

      const result = await documentService.updateDocument("doc-1", updateData);

      expect(api.put).toHaveBeenCalledWith("/documents/doc-1", updateData);
      expect(result).toEqual(mockResponse.data);
    });
  });

  describe("uploadNewVersion", () => {
    test("uploads new document version", async () => {
      const mockResponse = {
        data: {
          version: { _id: "version-3", versionNumber: 3 },
        },
      };

      (api.post as jest.Mock).mockResolvedValue(mockResponse);

      const formData = new FormData();
      formData.append(
        "file",
        new File(["test"], "test.pdf", { type: "application/pdf" })
      );
      formData.append("changeSummary", "Updated content");

      const result = await documentService.uploadNewVersion(
        "doc-1",
        formData,
        "user-1"
      );

      expect(api.post).toHaveBeenCalledWith(
        "/documents/doc-1/versions",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      expect(result).toEqual(mockResponse.data);
    });
  });

  describe("deleteDocument", () => {
    test("deletes document by ID", async () => {
      const mockResponse = {
        data: { message: "Document deleted successfully" },
      };

      (api.delete as jest.Mock).mockResolvedValue(mockResponse);

      const result = await documentService.deleteDocument("doc-1");

      expect(api.delete).toHaveBeenCalledWith("/documents/doc-1");
      expect(result).toEqual(mockResponse.data);
    });
  });

  describe("downloadDocument", () => {
    test("downloads latest document version", async () => {
      const mockBlob = new Blob(["test content"], { type: "application/pdf" });

      (api.get as jest.Mock).mockResolvedValue({
        data: mockBlob,
      });

      const result = await documentService.downloadDocument("doc-1");

      expect(api.get).toHaveBeenCalledWith("/documents/doc-1/download", {
        responseType: "blob",
      });

      expect(result).toEqual(mockBlob);
    });
  });

  describe("downloadDocumentVersion", () => {
    test("downloads specific document version", async () => {
      const mockBlob = new Blob(["test content"], { type: "application/pdf" });

      (api.get as jest.Mock).mockResolvedValue({
        data: mockBlob,
      });

      const result = await documentService.downloadDocumentVersion("doc-1", 2);

      expect(api.get).toHaveBeenCalledWith(
        "/documents/doc-1/versions/2/download",
        {
          responseType: "blob",
        }
      );

      expect(result).toEqual(mockBlob);
    });
  });
});
