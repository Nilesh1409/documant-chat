import { authService } from "@/services/auth-service";
import { api } from "@/lib/api";

// Mock axios
jest.mock("@/lib/api", () => ({
  api: {
    post: jest.fn(),
    get: jest.fn(),
  },
}));

describe("Auth Service", () => {
  beforeEach(() => {
    jest.clearAllMocks();
    localStorage.clear();
  });

  describe("login", () => {
    test("successful login returns user and token", async () => {
      const mockResponse = {
        data: {
          user: { _id: "user-1", email: "test@example.com", role: "viewer" },
          token: "mock-jwt-token",
        },
      };

      (api.post as jest.Mock).mockResolvedValue(mockResponse);

      const result = await authService.login("test@example.com", "password123");

      expect(api.post).toHaveBeenCalledWith("/auth/login", {
        email: "test@example.com",
        password: "password123",
      });

      expect(result).toEqual(mockResponse.data);
      expect(localStorage.getItem("token")).toBe("mock-jwt-token");
    });

    test("failed login throws error", async () => {
      (api.post as jest.Mock).mockRejectedValue({
        response: {
          data: { message: "Invalid credentials" },
          status: 401,
        },
      });

      await expect(
        authService.login("test@example.com", "wrong-password")
      ).rejects.toThrow("Invalid credentials");

      expect(localStorage.getItem("token")).toBeNull();
    });
  });

  describe("register", () => {
    test("successful registration returns user and token", async () => {
      const mockResponse = {
        data: {
          user: {
            _id: "user-1",
            email: "new@example.com",
            firstName: "New",
            lastName: "User",
            role: "viewer",
          },
          token: "mock-jwt-token",
        },
      };

      (api.post as jest.Mock).mockResolvedValue(mockResponse);

      const result = await authService.register({
        email: "new@example.com",
        password: "password123",
        firstName: "New",
        lastName: "User",
      });

      expect(api.post).toHaveBeenCalledWith("/auth/register", {
        email: "new@example.com",
        password: "password123",
        firstName: "New",
        lastName: "User",
      });

      expect(result).toEqual(mockResponse.data);
      expect(localStorage.getItem("token")).toBe("mock-jwt-token");
    });

    test("failed registration throws error", async () => {
      (api.post as jest.Mock).mockRejectedValue({
        response: {
          data: { message: "User already exists" },
          status: 400,
        },
      });

      await expect(
        authService.register({
          email: "existing@example.com",
          password: "password123",
          firstName: "Existing",
          lastName: "User",
        })
      ).rejects.toThrow("User already exists");

      expect(localStorage.getItem("token")).toBeNull();
    });
  });

  describe("getCurrentUser", () => {
    test("returns user when token is valid", async () => {
      const mockUser = {
        _id: "user-1",
        email: "test@example.com",
        role: "viewer",
      };

      (api.get as jest.Mock).mockResolvedValue({ data: { user: mockUser } });

      // Set token in localStorage
      localStorage.setItem("token", "mock-jwt-token");

      const result = await authService.getCurrentUser();

      expect(api.get).toHaveBeenCalledWith("/auth/me");
      expect(result).toEqual(mockUser);
    });

    test("returns null when no token is present", async () => {
      const result = await authService.getCurrentUser();

      expect(api.get).not.toHaveBeenCalled();
      expect(result).toBeNull();
    });

    test("returns null and clears token when API call fails", async () => {
      (api.get as jest.Mock).mockRejectedValue({
        response: {
          status: 401,
          data: { message: "Invalid token" },
        },
      });

      // Set token in localStorage
      localStorage.setItem("token", "invalid-token");

      const result = await authService.getCurrentUser();

      expect(api.get).toHaveBeenCalledWith("/auth/me");
      expect(result).toBeNull();
      expect(localStorage.getItem("token")).toBeNull();
    });
  });

  describe("logout", () => {
    test("clears token from localStorage", () => {
      // Set token in localStorage
      localStorage.setItem("token", "mock-jwt-token");

      authService.logout();

      expect(localStorage.getItem("token")).toBeNull();
    });
  });
});
